/***********************************************************************
 * Module:  Secretary.cs
 * Author:  Mirko
 * Purpose: Definition of the Class Model.Secretary
 ***********************************************************************/

namespace Model
{
    public class Secretary : Person
    {
        public Secretary()
        {
            // TODO: implement
        }

        ~Secretary()
        {
            // TODO: implement
        }

    }
}