/***********************************************************************
 * Module:  TypeOfAppointment.cs
 * Author:  Mirko
 * Purpose: Definition of the Enum Model.TypeOfAppointment
 ***********************************************************************/

namespace Model
{
    public enum TypeOfAppointment
    {
        Operacija,
        Pregled
    }
}