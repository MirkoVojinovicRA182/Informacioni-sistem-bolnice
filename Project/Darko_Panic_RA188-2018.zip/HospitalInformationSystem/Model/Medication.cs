﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public enum Medication
    {
        Metformin,
        Amlodipine,
        Metoprolol,
        Omeprazole,
        Simvastatin,
        Losartan,
        Albuterol
    }
}
