/***********************************************************************
 * Module:  Manager.cs
 * Author:  Mirko
 * Purpose: Definition of the Class Model.Manager
 ***********************************************************************/

namespace Model
{
    public class Manager : Person
    {
        public Manager()
        {
            // TODO: implement
        }

        ~Manager()
        {
            // TODO: implement
        }

    }
}