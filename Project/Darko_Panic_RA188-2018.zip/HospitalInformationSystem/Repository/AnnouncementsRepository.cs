﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalInformationSystem.Repository
{
    class AnnouncementsRepository : IRepository
    {
        public void loadFromFile()
        {
            throw new NotImplementedException();
        }

        public void saveInFile()
        {
            throw new NotImplementedException();
        }
    }
}
